print("load in mx module ")
vary = 100

def mul(x, y):
    print("mul in mx module")
    return x*y

def add(x, y):
    print("add in mx module")
    return x+y