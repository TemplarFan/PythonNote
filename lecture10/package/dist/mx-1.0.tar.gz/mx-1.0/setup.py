#setup.py

from distutils.core import setup

setup(name="mx",
      version="1.0",
      py_modules= ["mx"],
     )